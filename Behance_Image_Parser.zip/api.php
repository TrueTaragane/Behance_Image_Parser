<?php
declare(strict_types=1);

header('Content-Type: application/json');

function getFileContent(string $filename, array $default = []): array {
    $filepath = __DIR__ . '/' . $filename;
    if (!file_exists($filepath)) {
        file_put_contents($filepath, implode("\n", $default));
        return $default;
    }
    return array_filter(explode("\n", file_get_contents($filepath)), fn($item) => !empty(trim($item)));
}

function saveFileContent(string $filename, array $data): bool {
    return file_put_contents(__DIR__ . '/' . $filename, implode("\n", $data)) !== false;
}

function getLinks(): array {
    return getFileContent('links.txt');
}

function saveLinks(array $links): bool {
    return saveFileContent('links.txt', $links);
}

function getIgnorePatterns(): array {
    return getFileContent('ignore.txt', ['blank.png', 'placeholder', 'empty-image']);
}

function saveIgnorePatterns(array $patterns): bool {
    return saveFileContent('ignore.txt', $patterns);
}

function shouldIgnoreImage(string $url, array $ignorePatterns): bool {
    if (empty($url)) return true;
    
    $path = parse_url($url, PHP_URL_PATH);
    $filename = strtolower(basename($path));
    $dirname = strtolower(dirname($path));

    foreach ($ignorePatterns as $pattern) {
        $pattern = strtolower(trim($pattern));
        if (empty($pattern)) continue;
        
        if (strpos($filename, $pattern) !== false || strpos($dirname, $pattern) !== false) {
            return true;
        }
    }
    return false;
}

function sanitizeFilename(string $filename): string {
    $filename = preg_replace('/[^a-zA-Z0-9-_]/', '_', $filename);
    return substr($filename, 0, 50); // Ограничиваем длину имени
}

function getFileExtension(string $url): string {
    $path = parse_url($url, PHP_URL_PATH);
    $ext = pathinfo($path, PATHINFO_EXTENSION);
    return $ext ? '.' . strtolower($ext) : '.jpg';
}

function parseBehanceProject(string $url): array {
    $result = [
        'url' => $url,
        'name' => sanitizeFilename(pathinfo(parse_url($url, PHP_URL_PATH), PATHINFO_FILENAME)),
        'images' => []
    ];

    $html = @file_get_contents($url);
    if ($html === false) return $result;

    $ignorePatterns = getIgnorePatterns();
    $foundUrls = [];

    preg_match_all(
        '/https:\/\/mir-s3-cdn-cf\.behance\.net\/project_modules\/(?:max_\d+\/|fs\/|disp\/|1400\/|hd\/)?([a-f0-9]+_[a-f0-9]+\.(?:jpg|png|webp|jpeg))/i', 
        $html, 
        $matches
    );

    foreach ($matches[0] as $imageUrl) {
        if (!shouldIgnoreImage($imageUrl, $ignorePatterns)) {
            $highQualityUrl = preg_replace(
                '/\/project_modules\/(?:max_\d+\/|fs\/|disp\/|1400\/|hd\/)/',
                '/project_modules/max_3840/',
                $imageUrl
            );
            $foundUrls[] = $highQualityUrl;
        }
    }

    preg_match_all('/<img[^>]+src="([^">]+)"[^>]*>/i', $html, $imgTags);
    foreach ($imgTags[1] as $imgUrl) {
        if (strpos($imgUrl, 'mir-s3-cdn-cf.behance.net') !== false && 
            !shouldIgnoreImage($imgUrl, $ignorePatterns)) {
            $foundUrls[] = $imgUrl;
        }
    }

    $result['images'] = array_values(array_unique($foundUrls));
    return $result;
}

$action = $_GET['action'] ?? '';

try {
    switch ($action) {
        case 'get_links':
            echo json_encode(['links' => getLinks()]);
            break;

        case 'save_links':
            $links = json_decode(file_get_contents('php://input'), true)['links'] ?? [];
            echo json_encode(['success' => saveLinks($links)]);
            break;

        case 'get_ignore_patterns':
            echo json_encode(['patterns' => getIgnorePatterns()]);
            break;

        case 'save_ignore_patterns':
            $patterns = json_decode(file_get_contents('php://input'), true)['patterns'] ?? [];
            echo json_encode(['success' => saveIgnorePatterns($patterns)]);
            break;

        case 'parse_projects':
            $projects = array_map('parseBehanceProject', getLinks());
            echo json_encode(['projects' => $projects]);
            break;

        case 'download_images':
            $selectedData = json_decode(file_get_contents('php://input'), true)['images'] ?? [];
            $projects = json_decode(file_get_contents('php://input'), true)['all_projects'] ?? [];
            
            if (empty($selectedData)) {
                throw new Exception('No images selected');
            }

            $zip = new ZipArchive();
            $zipFile = tempnam(sys_get_temp_dir(), 'behance_') . '.zip';

            if ($zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
                throw new Exception('Cannot create ZIP file');
            }

            $context = stream_context_create([
                'http' => [
                    'header' => "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36\r\n",
                    'timeout' => 15
                ],
                'ssl' => [
                    'verify_peer' => false,
                    'verify_peer_name' => false
                ]
            ]);

            $successCount = 0;
            $fileCounter = 1;

            foreach ($selectedData as $projectName => $projectData) {
                $safeProjectName = sanitizeFilename($projectName);
                $imageUrls = $projectData['urls'] ?? [];
                $downloadAll = $projectData['downloadAll'] ?? false;

                if ($downloadAll) {
                    $project = current(array_filter($projects, fn($p) => $p['name'] === $projectName));
                    if ($project && isset($project['images'])) {
                        $imageUrls = $project['images'];
                    }
                }

                foreach ($imageUrls as $image) {
                    $url = is_array($image) ? $image['url'] : $image;
                    $filename = is_array($image) ? $image['filename'] : $safeProjectName . '_' . $fileCounter++ . getFileExtension($url);
                    
                    $tries = 0;
                    $success = false;
                    $urlVariants = [
                        $url,
                        str_replace('max_3840', 'fs', $url),
                        str_replace('max_3840', '1400', $url),
                        str_replace('max_3840', 'disp', $url)
                    ];

                    while (!$success && $tries < count($urlVariants)) {
                        $imageData = @file_get_contents($urlVariants[$tries], false, $context);
                        if ($imageData !== false) {
                            if ($zip->addFromString($filename, $imageData)) {
                                $successCount++;
                                $success = true;
                            }
                        }
                        $tries++;
                    }
                }
            }

            $zip->close();

            if ($successCount === 0) {
                unlink($zipFile);
                throw new Exception('Failed to download any images');
            }

            header('Content-Type: application/zip');
            header('Content-Disposition: attachment; filename="behance_projects.zip"');
            header('Content-Length: ' . filesize($zipFile));
            readfile($zipFile);
            unlink($zipFile);
            exit;

        default:
            throw new Exception('Invalid action');
    }
} catch (Exception $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}