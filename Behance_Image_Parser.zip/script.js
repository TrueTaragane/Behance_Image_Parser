$(document).ready(function() {
    const state = {
        links: [],
        ignorePatterns: [],
        projects: [],
        selectedImages: new Map() // projectName -> { urls: Set, downloadAll: bool, excludedUrls: Set }
    };

    // Инициализация
    init();

    function init() {
        loadData();
        setupEventListeners();
        Fancybox.bind("[data-fancybox]");
    }

    function loadData() {
        $.when(
            $.get('api.php?action=get_links'),
            $.get('api.php?action=get_ignore_patterns')
        ).done(function(linksResponse, patternsResponse) {
            state.links = linksResponse[0].links || [];
            state.ignorePatterns = patternsResponse[0].patterns || [];
            renderLinks();
            renderIgnorePatterns();
        }).fail(showError);
    }

    function setupEventListeners() {
        $('#toggleLinksBtn').click(toggleLinksCollapse);
        $('#toggleIgnoreBtn').click(toggleIgnoreCollapse);
        $('#addLinkBtn').click(addLink);
        $('#saveLinksBtn').click(saveLinks);
        $('#saveIgnoreBtn').click(saveIgnorePatterns);
        $('#parseBtn').click(parseProjects);
        $('#downloadBtn').click(downloadSelected);
    }

    function renderLinks() {
        const $container = $('#linksContainer').empty();
        
        if (state.links.length === 0) {
            $container.html('<div class="text-muted text-center py-2">No links added yet</div>');
            return;
        }

        state.links.forEach((link, index) => {
            const $item = $(`
                <div class="list-group-item d-flex justify-content-between align-items-center">
                    <div class="d-flex align-items-center">
                        <a href="${link}" target="_blank" class="me-2 text-decoration-none">
                            <i class="fas fa-external-link-alt"></i>
                        </a>
                        <span class="text-truncate" style="max-width: 80%">${link}</span>
                    </div>
                    <button class="btn btn-sm btn-outline-danger remove-link-btn">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            `);
            
            $item.find('.remove-link-btn').click(() => {
                state.links.splice(index, 1);
                renderLinks();
            });
            
            $container.append($item);
        });
    }

    function renderIgnorePatterns() {
        $('#ignorePatternsTextarea').val(state.ignorePatterns.join('\n'));
    }

    function parseProjects() {
        if (state.links.length === 0) {
            showError('Please add at least one project link');
            return;
        }

        toggleLoading('#parseBtn', 'Parsing...');
        $('#progressBar').removeClass('d-none');
        state.selectedImages.clear();
        updateDownloadPanel();

        $.get('api.php?action=parse_projects')
            .done(response => {
                state.projects = response.projects || [];
                renderResults();
            })
            .fail(() => showError('Error parsing projects'))
            .always(() => {
                $('#progressBar').addClass('d-none');
                resetLoading('#parseBtn', 'Parse Projects');
            });
    }

    function renderResults() {
        const $container = $('#resultsContainer').empty();
        
        if (!state.projects || state.projects.length === 0) {
            $container.html('<div class="alert alert-info">No projects found</div>');
            $('#downloadPanel').addClass('d-none');
            return;
        }

        let hasImages = false;

        state.projects.forEach(project => {
            const images = Array.isArray(project.images) ? project.images : [];
            if (images.length === 0) return;
            
            hasImages = true;
            const $projectCard = createProjectCard(project, images);
            $container.append($projectCard);
        });

        if (hasImages) {
            $('#downloadPanel').removeClass('d-none');
        } else {
            $container.html('<div class="alert alert-info">No images found after filtering</div>');
            $('#downloadPanel').addClass('d-none');
        }

        setupCheckboxHandlers();
    }

    function createProjectCard(project, images) {
        if (!state.selectedImages.has(project.name)) {
            state.selectedImages.set(project.name, {
                urls: new Set(),
                downloadAll: false,
                excludedUrls: new Set()
            });
        }
        
        const projectData = state.selectedImages.get(project.name);
        const selectedCount = projectData.downloadAll ? 
            images.length - projectData.excludedUrls.size : 
            projectData.urls.size;

        return $(`
            <div class="card project-card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center position-relative">
                    <div style="margin-right: 50px;">
                        <h5 class="mb-1">${project.name || 'Untitled Project'}</h5>
                        <div class="d-flex align-items-center">
                            <a href="${project.url}" target="_blank" class="text-white me-2">
                                <i class="fas fa-external-link-alt"></i>
                            </a>
                            <small class="text-truncate d-inline-block" style="max-width: 200px">${project.url}</small>
                        </div>
                    </div>
                    <div class="d-flex align-items-center">
                        <span class="badge bg-light text-dark me-2">${images.length} images</span>
                        <div class="form-check form-switch">
                            <input class="form-check-input project-checkbox" type="checkbox" 
                                   id="project-${project.name}" data-project="${project.name}"
                                   ${projectData.downloadAll ? 'checked' : ''}>
                            <label class="form-check-label" for="project-${project.name}">
                                ${projectData.downloadAll ? 
                                    (projectData.excludedUrls.size > 0 ? 
                                        `All (${projectData.excludedUrls.size} excluded)` : 'All selected') : 
                                    `${selectedCount}/${images.length} selected`}
                            </label>
                        </div>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row">
                        ${images.map((url, index) => `
                            <div class="col-md-3 col-6 mb-3">
                                <div class="position-relative">
                                    <input type="checkbox" class="image-checkbox position-absolute" 
                                           style="top: 10px; left: 10px; z-index: 10;"
                                           id="img-${index}-${project.name}" 
                                           data-url="${url}"
                                           data-project="${project.name}"
                                           ${projectData.urls.has(url) || (projectData.downloadAll && !projectData.excludedUrls.has(url)) ? 'checked' : ''}
                                           ${projectData.downloadAll ? 'disabled' : ''}>
                                    <label class="w-100" for="img-${index}-${project.name}">
                                        <a href="${url}" data-fancybox="gallery-${project.name}" 
                                           data-caption="${project.name} - Image ${index + 1}">
                                            <img src="${url}" class="image-thumbnail w-100" loading="lazy">
                                        </a>
                                    </label>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `);
    }

    function setupCheckboxHandlers() {
        // Обработчики для чекбоксов изображений
        $('.image-checkbox').change(function() {
            const url = $(this).data('url');
            const projectName = $(this).data('project');
            const isChecked = $(this).is(':checked');
            
            if (!state.selectedImages.has(projectName)) {
                state.selectedImages.set(projectName, {
                    urls: new Set(),
                    downloadAll: false,
                    excludedUrls: new Set()
                });
            }
            
            const projectData = state.selectedImages.get(projectName);
            
            if (isChecked) {
                projectData.urls.add(url);
                projectData.excludedUrls.delete(url);
            } else {
                projectData.urls.delete(url);
                if (projectData.downloadAll) {
                    projectData.excludedUrls.add(url);
                }
            }
            
            updateProjectCheckboxState(projectName);
            updateDownloadPanel();
        });
        
        // Обработчики для чекбоксов проектов
        $('.project-checkbox').change(function() {
            const projectName = $(this).data('project');
            const isChecked = $(this).is(':checked');
            
            if (!state.selectedImages.has(projectName)) {
                state.selectedImages.set(projectName, {
                    urls: new Set(),
                    downloadAll: isChecked,
                    excludedUrls: new Set()
                });
            } else {
                const projectData = state.selectedImages.get(projectName);
                projectData.downloadAll = isChecked;
                if (!isChecked) {
                    projectData.excludedUrls.clear();
                }
            }
            
            // Обновляем состояние чекбоксов изображений
            $(`.image-checkbox[data-project="${projectName}"]`)
                .prop('disabled', isChecked)
                .prop('checked', isChecked)
                .trigger('change');
            
            updateProjectCheckboxState(projectName);
            updateDownloadPanel();
        });
    }

    function updateProjectCheckboxState(projectName) {
        const projectData = state.selectedImages.get(projectName);
        if (!projectData) return;
        
        const $projectCheckbox = $(`#project-${projectName}`);
        const totalImages = $(`.image-checkbox[data-project="${projectName}"]`).length;
        
        let labelText = '';
        if (projectData.downloadAll) {
            const excludedCount = projectData.excludedUrls.size;
            labelText = excludedCount > 0 ? `All (${excludedCount} excluded)` : 'All selected';
        } else {
            const selectedCount = projectData.urls.size;
            labelText = `${selectedCount}/${totalImages} selected`;
        }
        
        $projectCheckbox.next('label').text(labelText);
    }

    function prepareDownloadData() {
        const data = {};
        let fileCounter = 1;
        
        state.selectedImages.forEach((projectData, projectName) => {
            const project = state.projects.find(p => p.name === projectName);
            if (!project) return;
            
            // Создаем безопасное имя папки
            const safeProjectName = projectName
                .replace(/[^\w\s-]/g, '') // Удаляем спецсимволы
                .replace(/\s+/g, '_')     // Заменяем пробелы на подчеркивания
                .substring(0, 50);        // Ограничиваем длину
            
            if (projectData.downloadAll) {
                data[projectName] = {
                    urls: project.images
                        .filter(url => !projectData.excludedUrls.has(url))
                        .map(url => ({
                            url: url,
                            filename: `${safeProjectName}_${fileCounter++}${getFileExtension(url)}`
                        })),
                    downloadAll: true
                };
            } else {
                data[projectName] = {
                    urls: Array.from(projectData.urls)
                        .map(url => ({
                            url: url,
                            filename: `${safeProjectName}_${fileCounter++}${getFileExtension(url)}`
                        })),
                    downloadAll: false
                };
            }
        });
        
        return data;
    }

    function getFileExtension(url) {
        // Пытаемся извлечь расширение из URL
        const extensionMatch = url.match(/\.(jpe?g|png|gif|bmp|webp|svg)/i);
        if (extensionMatch && extensionMatch[1]) {
            return '.' + extensionMatch[1].toLowerCase();
        }
        // Если расширение не найдено, используем .jpg по умолчанию
        return '.jpg';
    }

    function downloadSelected() {
        const selectedData = prepareDownloadData();
        if (Object.keys(selectedData).length === 0) {
            showError('Please select at least one image or project');
            return;
        }

        toggleLoading('#downloadBtn', 'Preparing download...');
        
        fetch('api.php?action=download_images', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                images: selectedData,
                all_projects: state.projects
            })
        })
        .then(response => {
            if (!response.ok) throw new Error('Download failed');
            return response.blob();
        })
        .then(blob => {
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'behance_projects.zip';
            document.body.appendChild(a);
            a.click();
            URL.revokeObjectURL(url);
            a.remove();
        })
        .catch(() => showError('Error downloading images. Please try again.'))
        .finally(() => {
            resetLoading('#downloadBtn', '<i class="fas fa-download me-2"></i>Download Selected');
        });
    }

    function updateDownloadPanel() {
        let totalImages = 0;
        let totalProjects = 0;
        
        state.selectedImages.forEach((projectData, projectName) => {
            if (!projectData) return;
            
            const project = state.projects.find(p => p.name === projectName);
            if (!project) return;
            
            if (projectData.downloadAll) {
                totalProjects++;
                const excludedCount = projectData.excludedUrls ? projectData.excludedUrls.size : 0;
                totalImages += project.images.length - excludedCount;
            } else {
                totalImages += projectData.urls ? projectData.urls.size : 0;
            }
        });
        
        let statusText = '';
        if (totalProjects > 0 && totalImages > 0) {
            statusText = `${totalProjects} full projects + ${totalImages} images selected`;
        } else if (totalProjects > 0) {
            statusText = `${totalProjects} full projects selected`;
        } else if (totalImages > 0) {
            statusText = `${totalImages} images selected`;
        } else {
            statusText = 'Nothing selected';
        }
        
        $('#selectedCounter').text(statusText);
        $('#downloadBtn').prop('disabled', totalProjects + totalImages === 0);
    }

    function toggleLinksCollapse() {
        $('#linksCollapse').toggleClass('show');
        $('#toggleLinksBtn i').toggleClass('fa-chevron-down fa-chevron-up');
    }

    function toggleIgnoreCollapse() {
        $('#ignoreCollapse').toggleClass('show');
        $('#toggleIgnoreBtn i').toggleClass('fa-chevron-down fa-chevron-up');
    }

    function addLink() {
        const newLink = $('#newLinkInput').val().trim();
        if (!newLink) return;

        if (!isValidBehanceUrl(newLink)) {
            showError('Please enter a valid Behance project URL in format: https://www.behance.net/gallery/123456/Project-Name');
            return;
        }

        state.links.push(newLink);
        $('#newLinkInput').val('');
        renderLinks();
    }

    function saveLinks() {
        toggleLoading('#saveLinksBtn', 'Saving...');
        
        $.ajax({
            url: 'api.php?action=save_links',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ links: state.links }),
            success: () => showSuccess('Links saved successfully'),
            error: () => showError('Error saving links'),
            complete: () => resetLoading('#saveLinksBtn', 'Save Links')
        });
    }

    function saveIgnorePatterns() {
        const patterns = $('#ignorePatternsTextarea').val()
            .split('\n')
            .map(p => p.trim())
            .filter(p => p.length > 0);
        
        toggleLoading('#saveIgnoreBtn', 'Saving...');
        
        $.ajax({
            url: 'api.php?action=save_ignore_patterns',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({ patterns }),
            success: () => {
                state.ignorePatterns = patterns;
                showSuccess('Ignore patterns saved successfully');
                if (state.projects.length > 0) {
                    parseProjects();
                }
            },
            error: () => showError('Error saving ignore patterns'),
            complete: () => resetLoading('#saveIgnoreBtn', 'Save Patterns')
        });
    }

    function isValidBehanceUrl(url) {
        return /^https?:\/\/(www\.)?behance\.net\/gallery\/\d+/i.test(url);
    }

    // Вспомогательные функции
    function toggleLoading(selector, text) {
        $(selector)
            .prop('disabled', true)
            .html(`<i class="fas fa-spinner fa-spin me-2"></i>${text}`);
    }

    function resetLoading(selector, text) {
        $(selector)
            .prop('disabled', false)
            .html(text);
    }

    function showError(message) {
        alert('Error: ' + message);
    }

    function showSuccess(message) {
        alert('Success: ' + message);
    }
});